begin;
create table if not exists public.taxi_payment_quotes (
 token uuid primary key default gen_random_uuid(),
 slot_id uuid not null references public.taxi_slots(id),
 service text not null, trip text not null default '',
 pickup text not null, dropoff text not null,
 amount_cents integer not null check(amount_cents between 50 and 1000000),
 expires_at timestamptz not null default now()+interval '15 minutes',
 request_id uuid unique references public.taxi_requests(id),
 created_at timestamptz not null default now()
);
alter table public.taxi_payment_quotes enable row level security;
revoke all on public.taxi_payment_quotes from public,anon,authenticated;
grant all on public.taxi_payment_quotes to service_role;
alter table public.taxi_requests
 add column if not exists payment_status text not null default 'unpaid',
 add column if not exists stripe_checkout_session_id text,
 add column if not exists stripe_payment_intent_id text,
 add column if not exists paid_at timestamptz;
create unique index if not exists taxi_unique_checkout_session on public.taxi_requests(stripe_checkout_session_id) where stripe_checkout_session_id is not null;
create or replace function public.taxi_prepare_checkout(p_token uuid,p_customer jsonb) returns uuid
language plpgsql security definer set search_path='' as $$
declare q public.taxi_payment_quotes; rid uuid;
begin
 select * into q from public.taxi_payment_quotes where token=p_token for update;
 if not found then raise exception 'Quote not found.'; end if;
 if q.request_id is not null then return q.request_id; end if;
 if q.expires_at<now() then raise exception 'Quote expired. Calculate again.'; end if;
 rid:=public.taxi_request(q.slot_id,p_customer->>'name',p_customer->>'phone',p_customer->>'email',q.pickup,q.dropoff,(p_customer->>'passengers')::integer,(p_customer->>'luggage')::integer,p_customer->>'notes',q.service,q.trip,q.amount_cents/100.0);
 update public.taxi_requests set final_price=q.amount_cents/100.0,payment_status='checkout_pending' where id=rid;
 update public.taxi_payment_quotes set request_id=rid where token=p_token;
 return rid;
end; $$;
revoke all on function public.taxi_prepare_checkout(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.taxi_prepare_checkout(uuid,jsonb) to service_role;
-- Customer submissions must pass through the server quote and checkout handler.
revoke execute on function public.taxi_request(uuid,text,text,text,text,text,integer,integer,text,text,text,numeric) from anon,authenticated;
grant execute on function public.taxi_request(uuid,text,text,text,text,text,integer,integer,text,text,text,numeric) to service_role;
create or replace function public.taxi_decide(p_request uuid,p_status text,p_price numeric default null) returns void
language plpgsql security definer set search_path='' as $$
declare r public.taxi_requests; s public.taxi_slots;
begin
 if not public.taxi_is_admin() then raise exception 'Admin access required.'; end if;
 if p_status not in ('approved','declined','cancelled') then raise exception 'Invalid decision.'; end if;
 -- Lock slot before request, using the same lock order as submission.
 select * into r from public.taxi_requests where id=p_request;
 if not found then raise exception 'Request not found.'; end if;
 select * into s from public.taxi_slots where id=r.slot_id for update;
 select * into r from public.taxi_requests where id=p_request for update;
 if r.payment_status='checkout_pending' then raise exception 'Await payment or checkout expiry before deciding.'; end if;
 if p_status='approved' and r.stripe_checkout_session_id is not null and (r.payment_status<>'paid' or p_price is distinct from r.final_price) then raise exception 'Paid fare must remain unchanged.'; end if;
 if r.status not in ('pending','approved') or (r.status='approved' and p_status<>'cancelled') then raise exception 'This request has already been processed.'; end if;
 if p_status='approved' and (p_price is null or p_price<=0 or s.closed or s.starts_at<=now()) then raise exception 'Set a final price and verify this future slot is open.'; end if;
 update public.taxi_requests set payment_status=case when p_status in ('declined','cancelled') and payment_status='paid' then 'refund_pending' else payment_status end,status=p_status,final_price=case when p_status='approved' then p_price else final_price end where id=p_request;
end;
$$;

commit;
