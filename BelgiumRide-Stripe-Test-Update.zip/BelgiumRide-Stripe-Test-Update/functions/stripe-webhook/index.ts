import Stripe from "npm:stripe@^22";
import {createClient} from "npm:@supabase/supabase-js@2";
Deno.serve(async req=>{
 if(req.method!=="POST")return new Response("POST required",{status:405});
 const key=Deno.env.get("Belgiumride")?.trim(),secret=Deno.env.get("STRIPE_WEBHOOK_SECRET"),url=Deno.env.get("SUPABASE_URL"),dbKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
 if(!key?.startsWith("sk_test_")||!secret||!url||!dbKey)return new Response("Test webhook configuration incomplete",{status:503});
 const stripe=new Stripe(key);let event:Stripe.Event;
 try{event=await stripe.webhooks.constructEventAsync(await req.text(),req.headers.get("stripe-signature")||"",secret,undefined,Stripe.createSubtleCryptoProvider());}catch{return new Response("Invalid signature",{status:400});}
 if(!["checkout.session.completed","checkout.session.async_payment_succeeded","checkout.session.expired","checkout.session.async_payment_failed"].includes(event.type))return Response.json({received:true});
 const session=event.data.object as Stripe.Checkout.Session,id=session.metadata?.booking_id;
 if(!id)return Response.json({received:true});
 if(session.livemode)return new Response("Test events only",{status:400});
 const db=createClient(url,dbKey,{auth:{persistSession:false}});
 const {data:r,error}=await db.from("taxi_requests").select("*").eq("id",id).single();
 if(error||!r)return new Response("Booking lookup failed",{status:500});
 if(r.stripe_checkout_session_id!==session.id||r.final_price==null||session.currency!=="eur"||session.amount_total!==Math.round(Number(r.final_price)*100))return new Response("Booking mismatch",{status:409});
 const paid=session.payment_status==="paid";
 if(event.type==="checkout.session.completed"&&!paid)return Response.json({received:true});
 if(r.payment_status==="paid"||r.payment_status==="refund_pending"||r.payment_status==="refunded")return Response.json({received:true});
 const update=paid?{payment_status:"paid",stripe_payment_intent_id:typeof session.payment_intent==="string"?session.payment_intent:session.payment_intent?.id,paid_at:new Date().toISOString()}:{payment_status:event.type==="checkout.session.expired"?"expired":"failed",status:"cancelled"};
 const {data:changed,error:ue}=await db.from("taxi_requests").update(update).eq("id",id).eq("payment_status","checkout_pending").select("id");
 if(ue||!changed?.length)return new Response("Booking update failed; retry required",{status:500});
 return Response.json({received:true});
});
