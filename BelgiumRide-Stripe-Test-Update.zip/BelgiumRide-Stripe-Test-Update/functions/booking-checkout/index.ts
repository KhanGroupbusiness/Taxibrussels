import { createClient } from "npm:@supabase/supabase-js@2";
const SITE="https://khangroupbusiness.github.io/Taxibrussels/index.html";
const ORIGIN="https://khangroupbusiness.github.io";
const headers={"Access-Control-Allow-Origin":ORIGIN,"Access-Control-Allow-Headers":"authorization, apikey, content-type, x-client-info","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"};
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers});
const trips:Record<string,{key:string,hours:number}>={"Bruges Day Trip":{key:"trip_bruges",hours:8},"Ghent Day Trip":{key:"trip_ghent",hours:7},"Knokke Seaside Trip":{key:"trip_knokke",hours:8},"Brussels Private Tour":{key:"trip_brussels",hours:5}};
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response(null,{status:204,headers});
 if(req.method!=="POST")return reply({error:"POST required"},405);
 if(req.headers.get("origin") && req.headers.get("origin")!==ORIGIN)return reply({error:"Origin not allowed"},403);
 const key=Deno.env.get("Belgiumride")?.trim();
 // Deliberately test-only until refunds, notifications and operational checks are complete.
 if(!key?.startsWith("sk_test_"))return reply({error:"This version requires a Stripe test key."},503);
 const dbKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),dbUrl=Deno.env.get("SUPABASE_URL");
 if(!dbKey||!dbUrl)return reply({error:"Database configuration missing"},503);
 const db=createClient(dbUrl,dbKey,{auth:{persistSession:false}});
 try{
  const raw=await req.text();if(raw.length>12000)return reply({error:"Request too large"},413);
  const body=JSON.parse(raw);
  if(body.action==="quote"){
   const {slot_id,service,trip,vehicle}=body;
   const pickup=String(body.pickup||"").trim(),dropoff=String(body.dropoff||"").trim();
   if(!/^[0-9a-f-]{36}$/i.test(slot_id||"")||pickup.length<2||pickup.length>500||dropoff.length<2||dropoff.length>500)throw Error("Choose a pickup window and valid addresses.");
   if(!["Transfer","Day Trip"].includes(service)||!["standard","van","premium"].includes(vehicle))throw Error("Invalid service or vehicle.");
   const {data:s,error:se}=await db.from("taxi_slots").select("*").eq("id",slot_id).single();
   const start=Date.parse(s?.starts_at||""),end=Date.parse(s?.ends_at||"");
   if(se||!s||s.closed||s.service!==service||start<Date.now()+4*3600000||start>Date.now()+90*86400000)throw Error("Pickup window unavailable.");
   const {data:p,error:pe}=await db.from("taxi_pricing").select("*").eq("id",1).single();
   if(pe||!p)throw Error("Published pricing unavailable.");
   let amount:number,distance="Fixed trip",duration="";
   const multiplier=Number(p[vehicle+"_multiplier"]);
   if(service==="Day Trip"){
    const t=trips[trip];if(!t)throw Error("Choose a listed day trip.");
    if(end-start<t.hours*3600000)throw Error("Choose a longer pickup window.");
    amount=Number(p[t.key])*multiplier;duration=t.hours+" hours";
   }else{
    const mapsKey=Deno.env.get("GOOGLE_ROUTES_API_KEY");if(!mapsKey)throw Error("Transfer quotes need GOOGLE_ROUTES_API_KEY in Supabase Secrets. Day trips can already be tested.");
    const routeResponse=await fetch("https://routes.googleapis.com/directions/v2:computeRoutes",{method:"POST",signal:AbortSignal.timeout(15000),headers:{"Content-Type":"application/json","X-Goog-Api-Key":mapsKey,"X-Goog-FieldMask":"routes.distanceMeters,routes.duration"},body:JSON.stringify({origin:{address:pickup},destination:{address:dropoff},travelMode:"DRIVE",routingPreference:"TRAFFIC_UNAWARE"})});
    const routeData=await routeResponse.json();const route=routeData.routes?.[0];
    if(!routeResponse.ok||!route||!Number.isFinite(route.distanceMeters))throw Error("Route unavailable. Check the addresses and server Routes API configuration.");
    const km=route.distanceMeters/1000,seconds=Number(String(route.duration).replace("s",""));
    if(!Number.isFinite(seconds)||seconds<=0||seconds*1000>end-start)throw Error("This journey does not fit the selected pickup window.");
    amount=(Number(p.base_fee)+km*Number(p.per_km))*multiplier;
    if(/airport|aéroport|luchthaven|zaventem|charleroi|schiphol|cdg|orly/i.test(pickup))amount+=Number(p.airport_fee);
    const hour=Number(new Intl.DateTimeFormat("en-GB",{timeZone:"Europe/Brussels",hour:"2-digit",hourCycle:"h23"}).format(new Date(start)));
    if(hour>=22||hour<6)amount+=Number(p.night_fee);
    amount=Math.max(amount,Number(p.minimum_fare));distance=km.toFixed(1)+" km";duration=Math.ceil(seconds/60)+" min";
   }
   const cents=Math.round(amount*100);if(!Number.isSafeInteger(cents)||cents<50||cents>1000000)throw Error("Fare outside supported range.");
   const {data:q,error:qe}=await db.from("taxi_payment_quotes").insert({slot_id,service,trip:service==="Day Trip"?trip:"",pickup,dropoff,amount_cents:cents}).select("token,expires_at").single();
   if(qe)throw Error("Could not save quote. Check the payment SQL migration.");
   return reply({quote_token:q.token,expires_at:q.expires_at,price:cents/100,distance,duration});
  }
  if(body.action!=="checkout")throw Error("Invalid action.");
  const token=String(body.quote_token||"");if(!/^[0-9a-f-]{36}$/i.test(token))throw Error("Calculate a quote first.");
  const {data:rid,error:re}=await db.rpc("taxi_prepare_checkout",{p_token:token,p_customer:body.customer});
  if(re)throw Error(re.message);
  const {data:r,error:be}=await db.from("taxi_requests").select("*").eq("id",rid).single();
  if(be||!r)throw Error("Booking could not be read.");
  if(r.status!=="pending"||r.payment_status!=="checkout_pending")throw Error("This booking is no longer awaiting checkout.");
  if(r.stripe_checkout_session_id){
   const previous=await fetch("https://api.stripe.com/v1/checkout/sessions/"+encodeURIComponent(r.stripe_checkout_session_id),{headers:{Authorization:`Bearer ${key}`}});
   const existing=await previous.json();if(!previous.ok||existing.status!=="open"||!existing.url)throw Error("Checkout closed. Contact the driver with reference "+rid);
   return reply({url:existing.url,booking_id:rid});
  }
  const cents=Math.round(Number(r.final_price)*100);
  const form=new URLSearchParams({mode:"payment","line_items[0][price_data][currency]":"eur","line_items[0][price_data][unit_amount]":String(cents),"line_items[0][price_data][product_data][name]":"Belgium Ride — "+r.service,"line_items[0][quantity]":"1","metadata[booking_id]":rid,client_reference_id:rid,customer_email:r.email,success_url:SITE+"?payment=processing",cancel_url:SITE+"?payment=cancelled",expires_at:String(Math.floor(Date.parse(r.created_at)/1000)+31*60)});
  const sr=await fetch("https://api.stripe.com/v1/checkout/sessions",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/x-www-form-urlencoded","Idempotency-Key":"taxi-checkout-"+rid},body:form});
  const session=await sr.json();if(!sr.ok)throw Error(session.error?.message||"Stripe checkout failed. Retry using the same quote.");
  const {error:saveError}=await db.from("taxi_requests").update({stripe_checkout_session_id:session.id}).eq("id",rid).eq("payment_status","checkout_pending");
  if(saveError)throw Error("Checkout could not be linked. Retry using the same quote.");
  return reply({url:session.url,booking_id:rid});
 }catch(e){return reply({error:e instanceof Error?e.message:"Request failed"},400);}
});
